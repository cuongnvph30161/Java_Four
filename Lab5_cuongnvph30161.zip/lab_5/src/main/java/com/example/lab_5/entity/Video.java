package com.example.lab_5.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table()
public class Video {

}
